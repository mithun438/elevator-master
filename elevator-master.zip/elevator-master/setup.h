

#ifndef SETUP_H
#define SETUP_H

/*
 * Configure the clocks, GPIO and other peripherals as required by the demo.
 */
void prvSetupHardware( void );

#endif
